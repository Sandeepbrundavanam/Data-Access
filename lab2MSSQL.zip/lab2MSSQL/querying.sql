use AdventureWorks;
SELECT x.ProductID,x.Name,x.ListPrice,y.ProductCategoryID,y.Name,y.ModifiedDate,z.ProductModelID,z.CatalogDescription,z.rowguid,w.SalesOrderID
from SalesLT.Product x 
join SalesLT.ProductCategory y 
on x.ProductCategoryID=y.ProductCategoryID
join SalesLT.ProductModel z 
on z.ProductModelID=x.ProductModelID
join SalesLT.SalesOrderDetail w
on w.ProductID=x.ProductID